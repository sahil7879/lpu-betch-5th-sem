-- Replace PROJECT_ID before running.
-- This creates two logically equivalent tables for cost comparisons.

CREATE OR REPLACE TABLE `PROJECT_ID.demo1_costs.orders_unpartitioned` AS
SELECT
  order_id + (replica * 1000000) AS order_id,
  customer_id,
  order_date,
  order_timestamp,
  status,
  sales_channel,
  payment_method,
  order_total
FROM `PROJECT_ID.demo1_costs.orders_raw`
CROSS JOIN UNNEST(GENERATE_ARRAY(0, 99)) AS replica;

CREATE OR REPLACE TABLE `PROJECT_ID.demo1_costs.orders_partitioned`
PARTITION BY order_date
CLUSTER BY status, sales_channel AS
SELECT *
FROM `PROJECT_ID.demo1_costs.orders_unpartitioned`;

-- Both tables should contain 1,000,000 rows.
SELECT
  (SELECT COUNT(*) FROM `PROJECT_ID.demo1_costs.orders_unpartitioned`) AS unpartitioned_rows,
  (SELECT COUNT(*) FROM `PROJECT_ID.demo1_costs.orders_partitioned`) AS partitioned_rows;
