-- Replace PROJECT_ID with the project that contains your dataset.
-- Keep the dataset name as demo1_costs unless you deliberately changed it.

SELECT 'customers_raw' AS table_name, COUNT(*) AS row_count
FROM `PROJECT_ID.demo1_costs.customers_raw`
UNION ALL
SELECT 'products_raw', COUNT(*)
FROM `PROJECT_ID.demo1_costs.products_raw`
UNION ALL
SELECT 'orders_raw', COUNT(*)
FROM `PROJECT_ID.demo1_costs.orders_raw`
UNION ALL
SELECT 'order_items_raw', COUNT(*)
FROM `PROJECT_ID.demo1_costs.order_items_raw`;

-- Expected row counts:
-- customers_raw: 500
-- products_raw: 120
-- orders_raw: 10000
-- order_items_raw: 30034
