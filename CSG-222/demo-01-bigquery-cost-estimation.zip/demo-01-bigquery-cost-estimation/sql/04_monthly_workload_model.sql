-- Replace the six byte estimates with values collected from BigQuery dry runs.
-- Replace query_price_per_tib with the current price for your selected location.

WITH workload AS (
  SELECT 'Q1_all_columns' AS query_name, 0 AS bytes_per_run, 20 AS runs_per_day UNION ALL
  SELECT 'Q2_selected_columns', 0, 100 UNION ALL
  SELECT 'Q3_limit_100', 0, 10 UNION ALL
  SELECT 'Q4_unpartitioned_month', 0, 200 UNION ALL
  SELECT 'Q5_partitioned_month', 0, 200 UNION ALL
  SELECT 'Q6_partitioned_clustered', 0, 500
),
settings AS (
  SELECT
    30 AS days_per_month,
    CAST(6.25 AS NUMERIC) AS query_price_per_tib,
    CAST(1 AS NUMERIC) AS monthly_free_tib
),
calculated AS (
  SELECT
    query_name,
    bytes_per_run,
    runs_per_day,
    bytes_per_run * runs_per_day * days_per_month AS monthly_bytes
  FROM workload
  CROSS JOIN settings
)
SELECT
  query_name,
  bytes_per_run,
  runs_per_day,
  monthly_bytes,
  ROUND(monthly_bytes / POW(1024, 4), 6) AS monthly_tib_before_free_tier,
  ROUND((monthly_bytes / POW(1024, 4)) * query_price_per_tib, 4) AS gross_estimated_usd
FROM calculated
CROSS JOIN settings
ORDER BY monthly_bytes DESC;

-- The free tier is account-level and must not be subtracted independently from
-- every query row. Aggregate the workload first when calculating a final bill.
