-- Replace PROJECT_ID before using these queries.
-- IMPORTANT: first observe the validator estimate or run a dry run.
-- Do not execute every query immediately.

-- Q1: All columns, all dates.
SELECT *
FROM `PROJECT_ID.demo1_costs.orders_unpartitioned`;

-- Q2: Selected columns only. Compare estimated bytes with Q1.
SELECT order_date, status, order_total
FROM `PROJECT_ID.demo1_costs.orders_unpartitioned`;

-- Q3: LIMIT does not normally reduce bytes read from a non-clustered table.
SELECT *
FROM `PROJECT_ID.demo1_costs.orders_unpartitioned`
LIMIT 100;

-- Q4: Date filter on an unpartitioned table.
SELECT status, COUNT(*) AS orders, SUM(order_total) AS revenue
FROM `PROJECT_ID.demo1_costs.orders_unpartitioned`
WHERE order_date BETWEEN '2025-01-01' AND '2025-01-31'
GROUP BY status;

-- Q5: Same logic on the partitioned table. Partition pruning should reduce bytes.
SELECT status, COUNT(*) AS orders, SUM(order_total) AS revenue
FROM `PROJECT_ID.demo1_costs.orders_partitioned`
WHERE order_date BETWEEN '2025-01-01' AND '2025-01-31'
GROUP BY status;

-- Q6: Filter on clustered columns as well as the partitioning column.
SELECT status, sales_channel, COUNT(*) AS orders, SUM(order_total) AS revenue
FROM `PROJECT_ID.demo1_costs.orders_partitioned`
WHERE order_date BETWEEN '2025-01-01' AND '2025-01-31'
  AND status = 'DELIVERED'
  AND sales_channel = 'MOBILE'
GROUP BY status, sales_channel;
