# Demo 1 Lab Guide: Estimate Monthly BigQuery Costs

> **Course:** CSG 222 - Optimizing Data Warehouses with BigQuery  
> **Official practical:** Estimate monthly BigQuery costs, including region-specific pricing and fees  
> **Recommended duration:** Instructor demo: 45 minutes; student lab: 60-75 minutes  
> **Level:** Introductory/intermediate  
> **Data:** Synthetic e-commerce records included with this guide

## 1. Purpose

This demonstration shows how BigQuery costs are estimated before a workload is deployed. Students load a small synthetic warehouse, create larger comparison tables, inspect query byte estimates, compare partitioned and unpartitioned queries, and calculate a monthly cost projection.

The exercise emphasizes four ideas:

1. BigQuery query cost and storage cost are separate.
2. On-demand query cost is primarily related to bytes processed, not the number of result rows.
3. Selecting fewer columns and pruning partitions can reduce bytes processed.
4. Location, pricing model, free-tier usage, storage model, and data transfer assumptions must be stated in every estimate.

## 2. Files in this lab

```text
demo-01-bigquery-cost-estimation/
├── README.md
├── data/
│   ├── customers.csv
│   ├── products.csv
│   ├── orders.csv
│   └── order_items.csv
├── schemas/
│   ├── customers.schema.json
│   ├── products.schema.json
│   ├── orders.schema.json
│   └── order_items.schema.json
└── sql/
    ├── 01_validate_loaded_data.sql
    ├── 02_build_comparison_tables.sql
    ├── 03_cost_comparison_queries.sql
    └── 04_monthly_workload_model.sql
```

All names, email addresses, orders, and financial values are synthetic. The `example.edu` addresses do not represent real users.

## 3. Learning outcomes

After completing the lab, students should be able to:

- identify the compute and storage components of BigQuery pricing;
- find the current price for a selected BigQuery location;
- use the query validator and a dry run to estimate bytes processed;
- explain why `LIMIT` is not a reliable cost-control mechanism;
- compare an unpartitioned table with a partitioned and clustered table;
- calculate daily and monthly query volume in TiB;
- include free-tier and region assumptions without treating an estimate as a guaranteed bill;
- use maximum bytes billed as a query safety control.

## 4. Cost and access warning

This lab creates approximately one million synthetic fact rows. It is intentionally small, but it still uses cloud resources.

- Use an instructor-provided project, Google Skills temporary project, BigQuery Sandbox, or an approved personal project.
- Never use a project without the owner's permission.
- Confirm the dataset location before loading data; a dataset's location cannot be changed after creation.
- Use dry runs before executing comparison queries.
- Delete the dataset after the lab if it is no longer needed.
- Current prices and free-tier conditions can change. Always verify them on the official [BigQuery pricing page](https://cloud.google.com/bigquery/pricing).

## 5. Required access

Students need enough permission to:

- create a BigQuery dataset;
- create and query tables;
- run BigQuery jobs;
- delete their own lab dataset during cleanup.

In a controlled class project, the instructor should provide narrowly scoped access. Students should not be given Project Owner merely to complete this lab.

## 6. Architecture used in the demo

```text
Local synthetic CSV files
          |
          v
BigQuery dataset: demo1_costs
  ├── four small raw tables
  ├── orders_unpartitioned (1,000,000 rows)
  └── orders_partitioned (1,000,000 rows)
          |
          v
Dry-run bytes + storage size + workload frequency
          |
          v
Estimated monthly cost
```

## 7. Instructor preparation

Before class:

1. Download this complete folder from the GitHub repository.
2. Verify that all four CSV files are present.
3. Choose one location for the demonstration, such as `asia-south1`, `asia-south2`, `US`, or another institution-approved location.
4. Open the official pricing page and record the current rates for that location.
5. Confirm whether the project uses on-demand analysis pricing or a capacity reservation.
6. Test the lab in a disposable dataset.
7. Decide whether students will upload files through the console or use Cloud Shell and `bq`.

### Suggested teaching sequence

| Time | Instructor action | Student focus |
|---:|---|---|
| 0-5 min | Introduce compute versus storage pricing | Identify cost components |
| 5-15 min | Create dataset and load CSV files | Observe schema and logical types |
| 15-25 min | Build comparison tables | Understand partitioning/clustering metadata |
| 25-40 min | Compare query estimates | Predict before viewing estimates |
| 40-50 min | Build monthly projection | Convert bytes and state assumptions |
| 50-60 min | Discuss controls and cleanup | Explain dry runs and maximum bytes billed |

## 8. Part A - Record pricing assumptions

Open the official [BigQuery pricing page](https://cloud.google.com/bigquery/pricing) and complete this table. Do not copy rates from an old screenshot or this repository.

| Assumption | Your value |
|---|---|
| Date checked | |
| Billing currency | |
| Dataset location | |
| Compute model: on-demand or capacity | |
| On-demand analysis price per TiB, if applicable | |
| Monthly analysis free tier, if applicable | |
| Active logical storage price per GiB-month | |
| Long-term logical storage price per GiB-month | |
| Storage billing model used by dataset | |
| Data transfer assumption | |

### Discussion

Why is an estimate incomplete if it says only “the query scans 500 GB”?

## 9. Part B - Create the dataset

### Option 1: Google Cloud console

1. Open **BigQuery Studio** in the Google Cloud console.
2. In Explorer, select the assigned project.
3. Select **Create dataset**.
4. Enter dataset ID `demo1_costs`.
5. Select the instructor-approved location.
6. Leave the default table expiration empty unless your instructor specifies one.
7. Select **Create dataset**.

### Option 2: Cloud Shell

Replace `LOCATION` with the approved BigQuery location:

```bash
export PROJECT_ID="$(gcloud config get-value project)"
export BQ_LOCATION="LOCATION"
bq --location="$BQ_LOCATION" mk --dataset "$PROJECT_ID:demo1_costs"
```

### Checkpoint

Record:

- Project ID:
- Dataset ID:
- Dataset location:
- Why must all queries and load jobs use a compatible location?

## 10. Part C - Load the synthetic CSV files

Create these destination tables:

| CSV file | Destination table | Schema file |
|---|---|---|
| `customers.csv` | `customers_raw` | `customers.schema.json` |
| `products.csv` | `products_raw` | `products.schema.json` |
| `orders.csv` | `orders_raw` | `orders.schema.json` |
| `order_items.csv` | `order_items_raw` | `order_items.schema.json` |

### Console loading procedure

Repeat these steps for each file:

1. Open the `demo1_costs` dataset.
2. Select **Create table**.
3. For source, choose **Upload** and select the CSV file.
4. Select CSV as the file format.
5. Enter the destination table name from the table above.
6. Under schema, enable schema editing and enter the fields from the matching JSON schema file, or use auto-detect and then verify every type.
7. Under advanced options, set header rows to skip to `1` if it is not detected automatically.
8. Create the table.

### Cloud Shell loading procedure

Run these commands from the root of this lab folder. Replace `LOCATION`:

```bash
export PROJECT_ID="$(gcloud config get-value project)"
export BQ_LOCATION="LOCATION"

bq --location="$BQ_LOCATION" load --source_format=CSV --skip_leading_rows=1 \
  "$PROJECT_ID:demo1_costs.customers_raw" data/customers.csv schemas/customers.schema.json

bq --location="$BQ_LOCATION" load --source_format=CSV --skip_leading_rows=1 \
  "$PROJECT_ID:demo1_costs.products_raw" data/products.csv schemas/products.schema.json

bq --location="$BQ_LOCATION" load --source_format=CSV --skip_leading_rows=1 \
  "$PROJECT_ID:demo1_costs.orders_raw" data/orders.csv schemas/orders.schema.json

bq --location="$BQ_LOCATION" load --source_format=CSV --skip_leading_rows=1 \
  "$PROJECT_ID:demo1_costs.order_items_raw" data/order_items.csv schemas/order_items.schema.json
```

Batch loading into BigQuery using the shared slot pool is listed as a free operation, but stored data can incur storage charges. Verify the current pricing conditions before relying on that statement.

### Validate the load

Open `sql/01_validate_loaded_data.sql`, replace `PROJECT_ID`, and run it.

Expected counts:

| Table | Expected rows |
|---|---:|
| `customers_raw` | 500 |
| `products_raw` | 120 |
| `orders_raw` | 10,000 |
| `order_items_raw` | 30,034 |

Use the **Preview** tab when visually inspecting rows. Previewing is preferable to running `SELECT *` merely to look at data.

## 11. Part D - Build cost-comparison tables

Open `sql/02_build_comparison_tables.sql` and replace `PROJECT_ID`.

Before running it, predict:

1. Will the partitioned table contain fewer rows?
2. Does partitioning automatically reduce the cost of every query?
3. Which column should a query filter to enable partition pruning?

Run the script. It creates:

- `orders_unpartitioned`: one million rows with no partitioning;
- `orders_partitioned`: the same rows, partitioned by `order_date` and clustered by `status, sales_channel`.

After completion, open each table's **Details** tab and record:

| Property | Unpartitioned | Partitioned/clustered |
|---|---:|---:|
| Row count | | |
| Logical bytes | | |
| Physical bytes, if displayed | | |
| Partitioning field | | |
| Clustering fields | | |

## 12. Part E - Estimate queries before running them

Open `sql/03_cost_comparison_queries.sql`. Work with one query at a time.

### Method 1: Query validator

Paste a query into the editor. Wait for the green validation indicator and record the displayed data-processing estimate. Do not select **Run** yet.

### Method 2: `bq` dry run

Example:

```bash
bq query --location="$BQ_LOCATION" --use_legacy_sql=false --dry_run \
'SELECT order_date, status, order_total
 FROM `PROJECT_ID.demo1_costs.orders_unpartitioned`'
```

A dry run validates the query and estimates bytes without executing it.

### Experiment table

Record the estimate for Q1-Q6:

| Query | Design feature tested | Estimated bytes | Result rows, if executed | What caused the difference? |
|---|---|---:|---:|---|
| Q1 | All columns | | | |
| Q2 | Selected columns | | | |
| Q3 | `LIMIT 100` | | | |
| Q4 | Date filter, unpartitioned | | | |
| Q5 | Date filter, partitioned | | | |
| Q6 | Partition + clustered-column filters | | | |

### Required observations

1. Compare Q1 and Q2. Explain how columnar storage affects bytes processed.
2. Compare Q1 and Q3. Does `LIMIT 100` provide reliable cost control on the unpartitioned table?
3. Compare Q4 and Q5. Calculate the percentage reduction:

```text
reduction % = ((Q4 bytes - Q5 bytes) / Q4 bytes) × 100
```

4. Q6 uses clustered columns. Explain why the pre-run estimate can be an upper bound rather than a precise final billed-byte value.

## 13. Part F - Test a cost guardrail

Use maximum bytes billed to prevent an unexpectedly large query.

```bash
bq query --location="$BQ_LOCATION" \
  --use_legacy_sql=false \
  --maximum_bytes_billed=1000000 \
'SELECT * FROM `PROJECT_ID.demo1_costs.orders_unpartitioned`'
```

If the estimate is above the limit, BigQuery should reject the query before execution. Record the error.

Then answer:

- Did the failed query return data?
- Why is maximum bytes billed more useful than adding `LIMIT 100`?
- In a shared teaching project, what additional cost controls might an administrator consider?

## 14. Part G - Calculate a monthly workload estimate

### Conversion formulas

BigQuery documentation uses binary units:

```text
1 GiB = 1,073,741,824 bytes = 2^30 bytes
1 TiB = 1,099,511,627,776 bytes = 2^40 bytes
```

For an on-demand workload:

```text
monthly bytes = bytes per run × runs per day × days per month
monthly TiB = monthly bytes / 2^40
gross query cost = monthly TiB × regional price per TiB
```

The account-level free tier, credits, contractual discounts, taxes, and currency conversion must be applied only after the aggregate workload and billing context are known.

### SQL workload model

1. Copy the six dry-run byte estimates into `sql/04_monthly_workload_model.sql`.
2. Replace the sample price with the current price for the selected location.
3. Run the query.
4. Sum the workload before considering any account-level free tier.

Complete this summary:

| Item | Monthly estimate |
|---|---:|
| Total query bytes | |
| Total query TiB before free tier | |
| Gross query cost | |
| Estimated active logical storage GiB | |
| Gross active storage cost | |
| Additional transfer/streaming/service costs assumed | |
| Final estimated monthly amount | |

### Storage estimate

Use the table details to total the stored logical bytes:

```text
storage GiB = total logical bytes / 2^30
monthly storage estimate = storage GiB × regional GiB-month rate
```

State whether the tables are active or eligible for long-term storage. Data that is repeatedly replaced during this lab should not be modeled as long-term storage.

## 15. Region comparison

Choose two locations from the official pricing page, including the location selected for the dataset. Compare only equivalent SKUs and billing models.

| Factor | Location A | Location B |
|---|---|---|
| Location name | | |
| On-demand analysis price | | |
| Active logical storage price | | |
| Long-term logical storage price | | |
| Relevant data-transfer consideration | | |
| Data residency consideration | | |

Answer:

1. Is the cheapest listed query price automatically the best architectural choice?
2. How can moving data between locations introduce additional constraints or charges?
3. Why should compute resources and BigQuery datasets usually be colocated when they exchange data?

## 16. Student submission

Submit one Markdown or PDF report containing:

1. The completed pricing-assumptions table.
2. A screenshot or copied output of the four validation row counts.
3. The comparison-table metadata.
4. The Q1-Q6 estimate table.
5. The partition-pruning percentage calculation.
6. The maximum-bytes-billed error and explanation.
7. The monthly query and storage cost worksheet.
8. The two-location comparison.
9. A 150-200 word recommendation for controlling BigQuery costs in this workload.

Do not publish project IDs, billing account information, credentials, access tokens, or student personal data.

## 17. Assessment rubric (20 marks)

| Criterion | Marks |
|---|---:|
| Correct data load and validation | 3 |
| Accurate dry-run evidence | 4 |
| Correct partitioning and column-pruning analysis | 4 |
| Correct monthly query/storage calculations | 4 |
| Region and pricing assumptions clearly stated | 2 |
| Cost-control recommendations | 3 |

## 18. Cleanup

Only delete the dataset created for this lab. Confirm the project and dataset name first.

### Console

1. Select dataset `demo1_costs`.
2. Select **Delete**.
3. Confirm the exact dataset ID.

### Cloud Shell

```bash
bq rm -r -f -d "$PROJECT_ID:demo1_costs"
```

Verify that no unrelated dataset was selected.

## 19. Instructor expected findings

- Q2 should process fewer logical bytes than Q1 because it reads fewer columns.
- Q3 commonly processes approximately the same bytes as Q1 for a non-clustered table; limiting output rows is not the same as limiting input bytes.
- Q5 should process fewer bytes than Q4 because the date predicate enables partition pruning.
- Q6 can benefit from both partition pruning and clustered-block pruning, but the dry-run estimate for a clustered table can be an upper bound.
- The raw CSV file size is not the correct basis for estimating BigQuery query cost; use BigQuery's estimated logical bytes.
- The free tier is shared at the billing-account level under the conditions stated by Google. Students must not subtract it independently from each query.
- A regional price comparison is incomplete without data residency, latency, colocation, transfer, currency, tax, and organizational-policy assumptions.
- Capacity pricing cannot be estimated per query using only scanned bytes in the same way as on-demand pricing.

## 20. Troubleshooting

### “Table was not found in location …”

The job location does not match the dataset location, or the project/dataset/table name is wrong. Confirm all identifiers and set `--location` correctly.

### Date or timestamp loaded as STRING

Delete only the incorrectly loaded table and reload it with the supplied schema JSON instead of relying on auto-detection.

### Permission denied

Ask the project administrator for the minimum missing permission. Do not work around the problem by using a personal billing account or requesting Owner.

### Comparison table creation is slow

Change `GENERATE_ARRAY(0, 99)` to `GENERATE_ARRAY(0, 9)`. This produces 100,000 rows. Record the changed scale in the report.

### Estimated bytes are smaller than a classmate's

Confirm that both students use the same SQL, table design, row scale, data types, and project tables. BigQuery optimizations and clustered-table estimates can also affect displayed values.

## 21. Authoritative references

- [BigQuery pricing](https://cloud.google.com/bigquery/pricing)
- [Estimate and control BigQuery costs](https://cloud.google.com/bigquery/docs/best-practices-costs)
- [BigQuery locations](https://cloud.google.com/bigquery/docs/locations)
- [Google Cloud Pricing Calculator](https://cloud.google.com/products/calculator)

Prices are intentionally not permanently embedded in this guide. Students must record the date, location, currency, and current SKU price used for their estimate.
